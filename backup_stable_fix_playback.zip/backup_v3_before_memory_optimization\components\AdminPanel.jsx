import React, { useState, useEffect } from 'react';
import {
    Layout, X, Save, Loader2, AlertCircle,
    CheckCircle, FileImage, FileVideo, PlayCircle, Newspaper, Trash2,
    Plus, Volume2, ArrowUp, ArrowDown, Image, Settings, Lock
} from 'lucide-react';
import { db, storage, appId } from '../firebase/client';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { LOGO_URL } from '../constants';

export default function AdminPanel({ collectionId = 'tv_config', playlist, setPlaylist, news, setNews, onClose, user, settings }) {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [loginUser, setLoginUser] = useState('');
    const [loginPass, setLoginPass] = useState('');
    const [loginError, setLoginError] = useState('');
    const [isLoggingIn, setIsLoggingIn] = useState(false);
    const [storedCredentials, setStoredCredentials] = useState({ adminUser: 'admin', adminPass: 'admin' });

    const [newItem, setNewItem] = useState({ type: 'image', src: '', title: '', subtitle: '', duration: 8000 });
    const [newNews, setNewNews] = useState('');
    const [editSettings, setEditSettings] = useState(settings || {});
    const [errorMsg, setErrorMsg] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const [activeTab, setActiveTab] = useState('playlist');
    const [itemsToDelete, setItemsToDelete] = useState([]);

    // Force basic styles reset and fetch credentials
    useEffect(() => {
        document.body.style.overflow = 'hidden';
        const isAuth = sessionStorage.getItem('gmad_admin_auth');
        if (isAuth === 'true') setIsAuthenticated(true);

        // Fetch stored credentials from Firestore
        const fetchCredentials = async () => {
            if (!db) return;
            try {
                const credRef = doc(db, 'artifacts', appId, 'public', 'data', collectionId, 'settings');
                const credSnap = await getDoc(credRef);
                if (credSnap.exists()) {
                    const data = credSnap.data();
                    if (data.adminUser && data.adminPass) {
                        setStoredCredentials({ adminUser: data.adminUser, adminPass: data.adminPass });
                    }
                }
            } catch (err) {
                console.error('Failed to fetch credentials', err);
            }
        };
        fetchCredentials();

        return () => {
            document.body.style.overflow = '';
        };
    }, [collectionId]);

    useEffect(() => {
        if (settings) setEditSettings(settings);
    }, [settings]);

    const handleLogin = async (e) => {
        e.preventDefault();
        setIsLoggingIn(true);
        setLoginError('');

        // Re-fetch credentials in case they were updated
        let creds = storedCredentials;
        if (db) {
            try {
                const credRef = doc(db, 'artifacts', appId, 'public', 'data', collectionId, 'settings');
                const credSnap = await getDoc(credRef);
                if (credSnap.exists()) {
                    const data = credSnap.data();
                    if (data.adminUser && data.adminPass) {
                        creds = { adminUser: data.adminUser, adminPass: data.adminPass };
                    }
                }
            } catch (err) {
                console.error('Failed to fetch credentials', err);
            }
        }

        if (loginUser === creds.adminUser && loginPass === creds.adminPass) {
            setIsAuthenticated(true);
            sessionStorage.setItem('gmad_admin_auth', 'true');
        } else {
            setLoginError('Usuário ou senha incorretos');
        }
        setIsLoggingIn(false);
    };

    // Styles Object using Pixels explicitly
    const s = {
        overlay: { position: 'fixed', inset: 0, zIndex: 9999, backgroundColor: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Arial, sans-serif' },
        window: { width: '95%', height: '90%', maxWidth: '1600px', maxHeight: '1000px', backgroundColor: '#f3f4f6', borderRadius: '16px', display: 'flex', overflow: 'hidden', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)' },
        sidebar: { width: '300px', backgroundColor: '#14532d', color: 'white', display: 'flex', flexDirection: 'column', flexShrink: 0 },
        main: { flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' },
        header: { height: '80px', backgroundColor: 'white', borderBottom: '1px solid #e5e7eb', padding: '0 30px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 },
        content: { flex: 1, overflowY: 'auto', padding: '30px' },

        // Components
        btnNav: (active) => ({
            width: '100%', padding: '15px 20px', display: 'flex', alignItems: 'center', gap: '15px',
            backgroundColor: active ? '#f97316' : 'transparent', color: active ? 'white' : '#dcfce7',
            border: 'none', cursor: 'pointer', fontSize: '16px', fontWeight: 'bold', textAlign: 'left',
            transition: 'background 0.2s'
        }),
        input: { height: '50px', width: '100%', padding: '0 15px', borderRadius: '8px', border: '1px solid #ccc', fontSize: '16px', color: '#1f2937', backgroundColor: '#ffffff' },
        btnAction: { height: '50px', padding: '0 25px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontSize: '16px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '10px', color: 'white' },
        card: { backgroundColor: 'white', padding: '25px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', marginBottom: '20px' }
    };

    if (!isAuthenticated) {
        return (
            <div style={s.overlay}>
                <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '16px', width: '400px', textAlign: 'center', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)' }}>
                    <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'center' }}>
                        <div style={{ padding: '15px', borderRadius: '50%', backgroundColor: '#dcfce7', color: '#166534' }}>
                            <Lock size={40} />
                        </div>
                    </div>
                    <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827', marginBottom: '10px' }}>Acesso Restrito</h2>
                    <p style={{ color: '#6b7280', marginBottom: '30px' }}>Entre com suas credenciais de administrador.</p>

                    <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                        <input
                            type="text"
                            placeholder="Usuário"
                            value={loginUser}
                            onChange={e => setLoginUser(e.target.value)}
                            style={{ ...s.input, backgroundColor: '#f9fafb' }}
                        />
                        <input
                            type="password"
                            placeholder="Senha"
                            value={loginPass}
                            onChange={e => setLoginPass(e.target.value)}
                            style={{ ...s.input, backgroundColor: '#f9fafb' }}
                        />
                        {loginError && <div style={{ color: '#ef4444', fontSize: '14px', fontWeight: 'bold' }}>{loginError}</div>}

                        <button type="submit" disabled={isLoggingIn} style={{ ...s.btnAction, justifyContent: 'center', backgroundColor: isLoggingIn ? '#9ca3af' : '#166534', marginTop: '10px' }}>
                            {isLoggingIn ? <Loader2 className="animate-spin" size={20} /> : 'Entrar'}
                        </button>
                        <button type="button" onClick={onClose} style={{ border: 'none', background: 'none', color: '#6b7280', marginTop: '10px', cursor: 'pointer', textDecoration: 'underline' }}>
                            Cancelar
                        </button>
                    </form>
                </div>
            </div>
        );
    }

    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (newItem.type === 'image' && !file.type.startsWith('image/')) {
            setErrorMsg('Selecione uma imagem válida.');
            return;
        }
        if (newItem.type === 'video' && !file.type.startsWith('video/')) {
            setErrorMsg('Selecione um vídeo válido.');
            return;
        }

        setIsUploading(true);
        setErrorMsg('');

        try {
            if (!storage) throw new Error("Storage inválido");
            const safeName = file.name.replace(/[^a-zA-Z0-9.]/g, '_');
            const storageRef = ref(storage, `artifacts/${appId}/public/${Date.now()}_${safeName}`);
            const snapshot = await uploadBytes(storageRef, file);
            const downloadURL = await getDownloadURL(snapshot.ref);
            setNewItem(prev => ({ ...prev, src: downloadURL }));
            setIsUploading(false);
        } catch (error) {
            console.warn("Upload falhou, fallback local", error);
            if (newItem.type === 'image' && file.size < 2 * 1024 * 1024) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    setNewItem(prev => ({ ...prev, src: reader.result }));
                    setIsUploading(false);
                };
                reader.readAsDataURL(file);
            } else {
                setErrorMsg("Erro no upload. Tente arquivo menor.");
                setIsUploading(false);
            }
        }
    };

    const handleAddItem = (e) => {
        e.preventDefault();
        setErrorMsg('');
        if (newItem.type !== 'news_joinville' && (!newItem.src.trim() || !newItem.title.trim())) {
            setErrorMsg('Preencha título e mídia!');
            return;
        }
        const item = { ...newItem, src: newItem.type === 'news_joinville' ? '' : newItem.src, title: newItem.type === 'news_joinville' ? 'Feed de Notícias' : newItem.title, id: Date.now() };
        setPlaylist([...playlist, item]);
        setNewItem({ type: 'image', src: '', title: '', subtitle: '', duration: 8000 });
    };

    const handleDeleteItem = (id) => {
        const item = playlist.find(i => i.id === id);
        // Se for um arquivo do Firebase Storage, marcar para deletar
        if (item && item.src && item.src.includes('firebasestorage')) {
            setItemsToDelete(prev => [...prev, item]);
        }
        setPlaylist(playlist.filter(item => item.id !== id));
    };

    const handleUpdateDuration = (id, newDuration) => {
        setPlaylist(playlist.map(item =>
            item.id === id ? { ...item, duration: newDuration * 1000 } : item
        ));
    };

    const handleMovePlaylistItem = (index, direction) => {
        const newPlaylist = [...playlist];
        const newIndex = direction === 'up' ? index - 1 : index + 1;
        if (newIndex < 0 || newIndex >= newPlaylist.length) return;
        [newPlaylist[index], newPlaylist[newIndex]] = [newPlaylist[newIndex], newPlaylist[index]];
        setPlaylist(newPlaylist);
    };

    const handleImportFromMain = async () => {
        if (!window.confirm("Isso substituirá a playlist atual pela da TV Principal. Continuar?")) return;
        try {
            const mainRef = doc(db, 'artifacts', appId, 'public', 'data', 'tv_config', 'playlist');
            const snap = await getDoc(mainRef);
            if (snap.exists()) {
                setPlaylist(snap.data().items);
            } else {
                alert("TV Principal não tem playlist salva.");
            }
        } catch (e) { alert("Erro: " + e.message); }
    };

    const handleSaveAll = async () => {
        setIsSaving(true);
        try {
            if (user && db) {
                // 1. Deletar arquivos marcados do Storage
                if (itemsToDelete.length > 0) {
                    await Promise.all(itemsToDelete.map(async (item) => {
                        try {
                            const fileRef = ref(storage, item.src);
                            await deleteObject(fileRef);
                        } catch (err) {
                            console.warn("Erro ao deletar do storage (pode já não existir):", err);
                        }
                    }));
                    setItemsToDelete([]);
                }

                // 2. Salvar Firestore na coleção correta
                await setDoc(doc(db, 'artifacts', appId, 'public', 'data', collectionId, 'playlist'), { items: playlist });
                await setDoc(doc(db, 'artifacts', appId, 'public', 'data', collectionId, 'news'), { items: news });
                await setDoc(doc(db, 'artifacts', appId, 'public', 'data', collectionId, 'settings'), editSettings);
                alert("Salvo com sucesso!");
            } else {
                localStorage.setItem('gmad_playlist', JSON.stringify(playlist));
                localStorage.setItem('gmad_news', JSON.stringify(news));
                alert("Salvo localmente!");
            }
            onClose();
        } catch (error) {
            alert("Erro: " + error.message);
        } finally {
            setIsSaving(false);
        }
    };



    // ... (unchanged code) ...

    return (
        <div style={s.overlay}>
            <div style={s.window}>
                {/* ... (sidebar unchanged) ... */}
                <div style={s.sidebar}>
                    <div style={{ padding: '30px', borderBottom: '1px solid rgba(255,255,255,0.1)', textAlign: 'center' }}>
                        <img src={LOGO_URL} style={{ height: '40px', marginBottom: '10px', filter: 'brightness(0) invert(1)' }} alt="Logo" />
                        <div style={{ fontSize: '12px', opacity: 0.7, textTransform: 'uppercase', letterSpacing: '1px' }}>Painel TV</div>
                        {collectionId !== 'tv_config' && (
                            <div style={{ fontSize: '10px', color: '#fb923c', marginTop: '4px', textTransform: 'uppercase' }}>
                                {collectionId.replace('tv_config_', '')}
                            </div>
                        )}
                    </div>
                    {/* ... (nav unchanged) ... */}
                    <nav style={{ padding: '20px', flex: 1 }}>
                        <button onClick={() => setActiveTab('playlist')} style={s.btnNav(activeTab === 'playlist')}>
                            <Layout size={20} /> Playlist
                        </button>
                        <div style={{ height: '10px' }}></div>
                        <button onClick={() => setActiveTab('news')} style={s.btnNav(activeTab === 'news')}>
                            <Volume2 size={20} /> Notícias
                        </button>
                        <div style={{ height: '10px' }}></div>
                        <button onClick={() => setActiveTab('settings')} style={s.btnNav(activeTab === 'settings')}>
                            <Settings size={20} /> Configurações
                        </button>
                    </nav>
                    <div style={{ padding: '20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                        <button onClick={onClose} style={{ ...s.btnNav(false), border: '1px solid rgba(255,255,255,0.3)', borderRadius: '8px', justifyContent: 'center' }}>
                            <X size={18} /> Fechar
                        </button>
                    </div>
                </div>

                {/* MAIN AREA */}
                <div style={s.main}>
                    <header style={s.header}>
                        <div>
                            <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: 0, color: '#1f2937' }}>
                                {activeTab === 'playlist' ? 'Gerenciar Playlist' : activeTab === 'news' ? 'Gerenciar Notícias' : 'Configurações da TV'}
                            </h2>
                        </div>
                        <button
                            onClick={handleSaveAll}
                            disabled={isSaving}
                            style={{ ...s.btnAction, backgroundColor: isSaving ? '#9ca3af' : '#15803d', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                        >
                            {isSaving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                            {isSaving ? 'Salvando...' : 'Salvar Alterações'}
                        </button>
                    </header>

                    <div style={s.content}>
                        {activeTab === 'playlist' && (
                            <>
                                <div style={s.card}>
                                    <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: '#374151', display: 'flex', alignItems: 'center', gap: '10px' }}>
                                        <Plus size={20} color="#f97316" /> Adicionar Novo Slide
                                        {collectionId !== 'tv_config' && (
                                            <button type="button" onClick={handleImportFromMain} style={{ fontSize: '12px', padding: '5px 10px', marginLeft: 'auto', backgroundColor: '#3b82f6', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                                                Importar da Principal
                                            </button>
                                        )}
                                    </h3>

                                    {errorMsg && <div style={{ padding: '15px', backgroundColor: '#fee2e2', color: '#b91c1c', borderRadius: '8px', marginBottom: '20px', display: 'flex', gap: '10px', alignItems: 'center' }}><AlertCircle size={20} /> {errorMsg}</div>}

                                    <form onSubmit={handleAddItem}>
                                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr 1fr', gap: '20px', marginBottom: '20px' }}>
                                            <div>
                                                <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px', textTransform: 'uppercase' }}>Tipo</label>
                                                <select style={s.input} value={newItem.type} onChange={e => setNewItem({ ...newItem, type: e.target.value, src: '' })}>
                                                    <option value="image">Imagem</option>
                                                    <option value="video">Vídeo</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px', textTransform: 'uppercase' }}>Título</label>
                                                <input type="text" style={s.input} placeholder="Ex: Promoção" value={newItem.title} onChange={e => setNewItem({ ...newItem, title: e.target.value })} disabled={newItem.type === 'news_joinville'} />
                                            </div>
                                            <div>
                                                <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px', textTransform: 'uppercase' }}>Segundos</label>
                                                <input type="number" style={s.input} value={newItem.duration / 1000} onChange={e => setNewItem({ ...newItem, duration: (parseInt(e.target.value) || 0) * 1000 })} disabled={newItem.type === 'video'} />
                                            </div>
                                            <div style={{ gridColumn: '1 / -1' }}>
                                                <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px', textTransform: 'uppercase' }}>Subtítulo (Opcional)</label>
                                                <input type="text" style={s.input} placeholder="Ex: Detalhes adicionais..." value={newItem.subtitle} onChange={e => setNewItem({ ...newItem, subtitle: e.target.value })} />
                                            </div>
                                        </div>

                                        {newItem.type !== 'news_joinville' && (
                                            <div style={{ border: '2px dashed #d1d5db', borderRadius: '12px', padding: '20px', marginBottom: '20px', backgroundColor: '#f9fafb', textAlign: 'center' }}>
                                                {!newItem.src && !isUploading ? (
                                                    <label style={{ cursor: 'pointer', display: 'block' }}>
                                                        <div style={{ marginBottom: '10px', color: '#f97316', display: 'flex', justifyContent: 'center' }}><FileImage size={40} /></div>
                                                        <div style={{ fontWeight: 'bold', color: '#374151' }}>Clique para selecionar arquivo</div>
                                                        <input type="file" style={{ display: 'none' }} accept={newItem.type === 'image' ? "image/*" : "video/*"} onChange={handleFileUpload} />
                                                    </label>
                                                ) : isUploading ? (
                                                    <div><Loader2 className="animate-spin" size={30} style={{ margin: '0 auto 10px', color: '#f97316' }} /> <span style={{ color: '#374151' }}>Enviando...</span></div>
                                                ) : (
                                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '15px' }}>
                                                        <CheckCircle size={30} color="#16a34a" />
                                                        <span style={{ fontWeight: 'bold', color: '#166534' }}>Arquivo pronto!</span>
                                                        <button type="button" onClick={() => setNewItem({ ...newItem, src: '' })} style={{ border: 'none', background: 'none', color: '#dc2626', cursor: 'pointer', textDecoration: 'underline' }}>Trocar</button>
                                                    </div>
                                                )}
                                            </div>
                                        )}

                                        <button type="submit" disabled={isUploading} style={{ ...s.btnAction, width: '100%', justifyContent: 'center', backgroundColor: '#111827' }}>
                                            <Plus size={20} /> Adicionar à Playlist
                                        </button>
                                    </form>
                                </div>

                                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                    <h3 style={{ fontSize: '18px', fontWeight: 'bold', color: '#374151' }}>Slides Ativos ({playlist.length})</h3>
                                    {playlist.map((item, idx) => (
                                        <div key={item.id} style={{ display: 'flex', alignItems: 'center', gap: '15px', padding: '15px', backgroundColor: 'white', borderRadius: '10px', boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>

                                            {/* Reorder Buttons */}
                                            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                                                <button disabled={idx === 0} onClick={() => handleMovePlaylistItem(idx, 'up')} style={{ background: 'none', border: 'none', cursor: idx === 0 ? 'default' : 'pointer', opacity: idx === 0 ? 0.3 : 1, padding: '4px' }}>
                                                    <ArrowUp size={24} color="#6b7280" />
                                                </button>
                                                <button disabled={idx === playlist.length - 1} onClick={() => handleMovePlaylistItem(idx, 'down')} style={{ background: 'none', border: 'none', cursor: idx === playlist.length - 1 ? 'default' : 'pointer', opacity: idx === playlist.length - 1 ? 0.3 : 1, padding: '4px' }}>
                                                    <ArrowDown size={24} color="#6b7280" />
                                                </button>
                                            </div>

                                            <div style={{ width: '100px', height: '60px', backgroundColor: '#f3f4f6', borderRadius: '8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #e5e7eb' }}>
                                                {item.type === 'image' && <img src={item.src} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                                                {item.type === 'video' && (
                                                    <video
                                                        src={item.src}
                                                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                                        muted
                                                        onMouseOver={e => e.target.play()}
                                                        onMouseOut={e => { e.target.pause(); e.target.currentTime = 0; }}
                                                    />
                                                )}
                                                {item.type === 'news_joinville' && <Newspaper size={24} color="#15803d" />}
                                            </div>

                                            <div style={{ flex: 1 }}>
                                                <div style={{ fontWeight: 'bold', fontSize: '16px', color: '#111827' }}>{item.title}</div>
                                                <div style={{ fontSize: '12px', color: '#6b7280', textTransform: 'uppercase', marginTop: '4px' }}>
                                                    {item.type === 'video' ? 'Vídeo' : item.type === 'news_joinville' ? 'Automático' : 'Imagem'}
                                                </div>
                                            </div>

                                            {/* Duration Edit */}
                                            {item.type !== 'video' && (
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '5px', backgroundColor: '#f9fafb', padding: '5px 10px', borderRadius: '6px', border: '1px solid #e5e7eb' }}>
                                                    <input
                                                        type="number"
                                                        value={item.duration / 1000}
                                                        onChange={(e) => handleUpdateDuration(item.id, parseInt(e.target.value) || 8)}
                                                        style={{ width: '40px', border: 'none', background: 'transparent', fontWeight: 'bold', textAlign: 'center', fontSize: '18px', color: '#111827' }}
                                                    />
                                                    <span style={{ fontSize: '12px', color: '#9ca3af', fontWeight: 'bold' }}>s</span>
                                                </div>
                                            )}

                                            <button onClick={() => handleDeleteItem(item.id)} style={{ border: 'none', background: '#fee2e2', color: '#b91c1c', padding: '12px', borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                                <Trash2 size={24} />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </>
                        )}

                        {activeTab === 'news' && (
                            <>
                                <div style={s.card}>
                                    <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: '#374151' }}>Adicionar Notícia</h3>
                                    <div style={{ display: 'flex', gap: '10px' }}>
                                        <input type="text" style={{ ...s.input, color: '#1f2937', backgroundColor: '#ffffff' }} placeholder="Texto da notícia..." value={newNews} onChange={e => setNewNews(e.target.value)} />
                                        <button onClick={() => { if (newNews) { setNews([...news, newNews]); setNewNews('') } }} style={{ ...s.btnAction, backgroundColor: '#111827' }}>Adicionar</button>
                                    </div>
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                    {news.map((n, i) => (
                                        <div key={i} style={{ padding: '15px', backgroundColor: 'white', borderRadius: '10px', boxShadow: '0 1px 2px rgba(0,0,0,0.05)', display: 'flex', gap: '15px', alignItems: 'center' }}>
                                            {/* Reorder Buttons */}
                                            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                                                <button disabled={i === 0} onClick={() => {
                                                    if (i > 0) { const a = [...news];[a[i - 1], a[i]] = [a[i], a[i - 1]]; setNews(a); }
                                                }} style={{ background: 'none', border: 'none', cursor: i === 0 ? 'default' : 'pointer', opacity: i === 0 ? 0.3 : 1, padding: '4px' }}>
                                                    <ArrowUp size={20} color="#6b7280" />
                                                </button>
                                                <button disabled={i === news.length - 1} onClick={() => {
                                                    if (i < news.length - 1) { const a = [...news];[a[i + 1], a[i]] = [a[i], a[i + 1]]; setNews(a); }
                                                }} style={{ background: 'none', border: 'none', cursor: i === news.length - 1 ? 'default' : 'pointer', opacity: i === news.length - 1 ? 0.3 : 1, padding: '4px' }}>
                                                    <ArrowDown size={20} color="#6b7280" />
                                                </button>
                                            </div>

                                            <div style={{ fontWeight: 'bold', color: '#9ca3af', fontSize: '14px' }}>#{i + 1}</div>
                                            <div style={{ flex: 1, fontSize: '16px', color: '#1f2937' }}>{n}</div>
                                            <button onClick={() => setNews(news.filter((_, idx) => idx !== i))} style={{ border: 'none', background: '#fee2e2', color: '#b91c1c', padding: '10px', borderRadius: '8px', cursor: 'pointer' }}><Trash2 size={20} /></button>
                                        </div>
                                    ))}
                                </div>
                            </>
                        )}

                        {activeTab === 'settings' && (
                            <div style={s.card}>
                                <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: '#374151' }}>Instagram Principal</h3>
                                <div style={{ display: 'grid', gap: '15px', marginBottom: '30px' }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>Usuário (@)</label>
                                        <input type="text" style={s.input} value={editSettings.instagramUser || ''} onChange={e => setEditSettings({ ...editSettings, instagramUser: e.target.value })} placeholder="@exemplo" />
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>URL do Perfil (para QR Code)</label>
                                        <input type="text" style={s.input} value={editSettings.instagramUrl || ''} onChange={e => setEditSettings({ ...editSettings, instagramUrl: e.target.value })} placeholder="https://instagram.com/..." />
                                    </div>
                                </div>

                                <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: '#374151' }}>Instagram Secundário (Opcional)</h3>
                                <div style={{ display: 'grid', gap: '15px', marginBottom: '30px' }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>Usuário (@)</label>
                                        <input type="text" style={s.input} value={editSettings.instagramUser2 || ''} onChange={e => setEditSettings({ ...editSettings, instagramUser2: e.target.value })} placeholder="@exemplo" />
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>URL do Perfil</label>
                                        <input type="text" style={s.input} value={editSettings.instagramUrl2 || ''} onChange={e => setEditSettings({ ...editSettings, instagramUrl2: e.target.value })} placeholder="https://instagram.com/..." />
                                    </div>
                                </div>

                                <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: '#374151' }}>Localização e Rede</h3>
                                <div style={{ display: 'grid', gap: '15px' }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>Cidade (Para Previsão do Tempo)</label>
                                        <input type="text" style={s.input} value={editSettings.weatherCity || ''} onChange={e => setEditSettings({ ...editSettings, weatherCity: e.target.value })} placeholder="Ex: Joinville" />
                                        <div style={{ fontSize: '10px', color: '#6b7280', marginTop: '4px' }}>Digite apenas o nome da cidade. O sistema busca as coordenadas automaticamente.</div>
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>Nome da Rede Wi-Fi</label>
                                        <input type="text" style={s.input} value={editSettings.wifiSsid || ''} onChange={e => setEditSettings({ ...editSettings, wifiSsid: e.target.value })} placeholder="Ex: GMAD Visitantes" />
                                    </div>
                                </div>

                                <hr style={{ border: 'none', borderTop: '1px solid #e5e7eb', margin: '30px 0' }} />

                                <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: '#374151', display: 'flex', alignItems: 'center', gap: '10px' }}>
                                    <Lock size={20} color="#f97316" /> Credenciais do Admin
                                </h3>
                                <div style={{ display: 'grid', gap: '15px' }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>Usuário</label>
                                        <input type="text" style={s.input} value={editSettings.adminUser || ''} onChange={e => setEditSettings({ ...editSettings, adminUser: e.target.value })} placeholder="admin" />
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#6b7280', marginBottom: '5px' }}>Nova Senha</label>
                                        <input type="password" style={s.input} value={editSettings.adminPass || ''} onChange={e => setEditSettings({ ...editSettings, adminPass: e.target.value })} placeholder="••••••••" />
                                        <div style={{ fontSize: '10px', color: '#6b7280', marginTop: '4px' }}>Deixe em branco para manter a senha atual. Padrão inicial: admin/admin</div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
